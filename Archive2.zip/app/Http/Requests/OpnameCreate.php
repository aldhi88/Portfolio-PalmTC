<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OpnameCreate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'stock_in' => 'nullable|numeric',
            'stock_out' => 'nullable|numeric',
        ];
    }

    public function messages()
    {
        return [
            'stock_in.numeric' => "The 'Stock In' field is numeric.",
            'stock_out.numeric' => "The 'Stock Out' field is numeric.",
        ];
    }
}
