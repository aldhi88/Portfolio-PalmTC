<?php

namespace App\Http\Livewire\Worker;

use Livewire\Component;

class WorkerData extends Component
{
    public function render()
    {
        return view('livewire.worker.worker-data');
    }
}
