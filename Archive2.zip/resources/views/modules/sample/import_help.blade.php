<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="sampleModalLabel"><i class="feather icon-plus"></i> Import Guide</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
    <div class="modal-body">
        
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat illo inventore earum, quasi facilis magnam perspiciatis odio vel cupiditate nobis praesentium numquam voluptas omnis similique assumenda temporibus voluptatum aspernatur. Deserunt!
        
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
    </div>
</div>