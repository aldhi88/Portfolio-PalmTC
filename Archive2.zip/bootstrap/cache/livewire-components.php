<?php return array (
  'worker.worker-data' => 'App\\Http\\Livewire\\Worker\\WorkerData',
);